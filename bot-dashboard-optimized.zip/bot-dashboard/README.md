# WhatsApp Bot Dashboard - Gold & Silver Premium

Dashboard profissional para gerenciamento de bot de WhatsApp com editor de código integrado, visualizador de logs em tempo real, painel de estatísticas e suporte a QR code para autenticação.

## 🎨 Design

- **Tema**: Gold & Silver Premium
- **Cores**: Ouro (#ffd700), Prata (#c0c0c0), Preto (#000000)
- **Efeitos**: Neon glow, HUD corners, scan lines
- **Sidebar**: Navegação intuitiva com abas (Dashboard, Estatísticas, Logs)

## ✨ Funcionalidades

### Editor de Código
- Suporte para múltiplos arquivos (index.js, package.json, system_prompt.txt)
- Syntax highlighting automático
- Salvar alterações em tempo real
- Abas de navegação entre arquivos

### Gerenciamento do Bot
- **Iniciar/Parar**: Controles para executar o bot
- **Status em Tempo Real**: Indicador visual de status (rodando/parado)
- **QR Code**: Renderização visual do QR code para autenticação WhatsApp
- **Logs em Tempo Real**: Visualizador de logs com auto-scroll

### Painel de Estatísticas
- Gráficos de histórico de mensagens
- Contador de mensagens processadas
- Tempo de uptime do bot
- Média de mensagens por minuto

### Dependências
- Listagem de todas as dependências instaladas
- Versões de cada pacote
- Painel dedicado com scroll

## 🚀 Quick Start

### Pré-requisitos
- Node.js 18+
- pnpm (recomendado)

### Instalação Local

```bash
# Clonar o repositório
git clone https://github.com/seu-usuario/bot-dashboard.git
cd bot-dashboard

# Instalar dependências
pnpm install

# Iniciar servidor de desenvolvimento
pnpm dev

# Acessar em http://localhost:3000
```

### Build para Produção

```bash
# Compilar projeto
pnpm build

# Iniciar servidor de produção
pnpm start
```

## 📦 Estrutura do Projeto

```
bot-dashboard/
├── client/                 # Frontend React 19
│   ├── src/
│   │   ├── pages/
│   │   │   └── BotDashboard.tsx    # Página principal
│   │   ├── components/
│   │   │   ├── Sidebar.tsx         # Navegação lateral
│   │   │   ├── QRCodeDisplay.tsx   # Renderizador de QR code
│   │   │   └── StatisticsPanel.tsx # Painel de estatísticas
│   │   ├── lib/trpc.ts             # Cliente tRPC
│   │   └── index.css               # Estilos globais (Gold & Silver)
│   └── public/                     # Assets estáticos
├── server/                 # Backend Express + tRPC
│   ├── routers.ts          # Rotas tRPC
│   ├── botManager.ts       # Lógica de gerenciamento do bot
│   ├── db.ts               # Queries do banco de dados
│   └── _core/              # Framework interno
├── drizzle/                # Migrations do banco
├── dist/                   # Build compilado
├── package.json            # Dependências
├── pnpm-lock.yaml          # Lock file
├── RAILWAY_DEPLOY.md       # Instruções de deploy na Railway
├── GITHUB_SETUP.md         # Instruções de setup no GitHub
└── railway.json            # Configuração do Railway
```

## 🔧 Variáveis de Ambiente

Crie um arquivo `.env` na raiz do projeto:

```env
DATABASE_URL=mysql://user:password@host:3306/database
JWT_SECRET=sua-chave-secreta-aqui
VITE_APP_ID=seu-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im
OWNER_OPEN_ID=seu-open-id
OWNER_NAME=seu-nome
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=sua-chave-api
VITE_FRONTEND_FORGE_API_KEY=sua-chave-frontend
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
```

## 🚀 Deploy

### Railway

Veja [RAILWAY_DEPLOY.md](./RAILWAY_DEPLOY.md) para instruções completas.

Resumo:
1. Faça push para GitHub
2. Conecte Railway ao repositório
3. Adicione variáveis de ambiente
4. Deploy automático

### GitHub

Veja [GITHUB_SETUP.md](./GITHUB_SETUP.md) para instruções completas.

Resumo:
```bash
git init
git add .
git commit -m "Initial commit"
git remote add origin https://github.com/seu-usuario/bot-dashboard.git
git push -u origin main
```

## 📊 Tecnologias

### Frontend
- **React 19** - UI library
- **Tailwind CSS 4** - Styling
- **TypeScript** - Type safety
- **Recharts** - Gráficos
- **Lucide React** - Ícones
- **shadcn/ui** - Componentes

### Backend
- **Express 4** - Web framework
- **tRPC 11** - RPC framework
- **Drizzle ORM** - Database ORM
- **MySQL** - Database

### DevTools
- **Vite** - Build tool
- **Vitest** - Testing framework
- **Prettier** - Code formatter
- **TypeScript** - Type checking

## 🧪 Testes

```bash
# Rodar testes
pnpm test

# Rodar testes com coverage
pnpm test -- --coverage

# Modo watch
pnpm test -- --watch
```

## 📝 Commits Semânticos

Use prefixos nos commits:

```bash
git commit -m "feat: Adicionar nova funcionalidade"
git commit -m "fix: Corrigir bug"
git commit -m "docs: Atualizar documentação"
git commit -m "style: Ajustar estilos"
git commit -m "refactor: Reorganizar código"
git commit -m "test: Adicionar testes"
git commit -m "chore: Atualizar dependências"
```

## 🐛 Troubleshooting

### Erro: "pnpm not found"
```bash
npm install -g pnpm
```

### Erro: "DATABASE_URL not set"
Certifique-se de que o arquivo `.env` existe e contém `DATABASE_URL`.

### Erro: "Port 3000 already in use"
```bash
# Usar porta diferente
PORT=3001 pnpm dev
```

### Erro: "Cannot find module"
```bash
# Reinstalar dependências
rm -rf node_modules pnpm-lock.yaml
pnpm install
```

## 📞 Suporte

Para dúvidas ou problemas:
1. Verifique a documentação em [RAILWAY_DEPLOY.md](./RAILWAY_DEPLOY.md) e [GITHUB_SETUP.md](./GITHUB_SETUP.md)
2. Abra uma issue no GitHub
3. Consulte a documentação das dependências

## 📄 Licença

MIT

## 🙏 Créditos

Desenvolvido com ❤️ usando Manus AI

---

**Versão**: 1.0.0  
**Última atualização**: 02 de Janeiro de 2026
