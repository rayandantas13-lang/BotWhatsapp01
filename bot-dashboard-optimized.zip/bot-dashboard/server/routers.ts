import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { getFiles, saveFiles, getDependencies, startBot, stopBot, getStatus, getStatistics } from "./botManager";
import { z } from "zod";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  bot: router({
    getFiles: publicProcedure.query(async () => {
      const files = await getFiles();
      return {
        success: true,
        files,
      };
    }),
    saveFiles: publicProcedure
      .input(z.array(z.object({
        name: z.string(),
        content: z.string(),
      })))
      .mutation(async ({ input }) => {
        await saveFiles(input);
        return {
          success: true,
          message: 'Arquivos salvos com sucesso',
        };
      }),
    start: publicProcedure.mutation(async () => {
      return await startBot();
    }),
    stop: publicProcedure.mutation(async () => {
      return await stopBot();
    }),
    getStatus: publicProcedure.query(async () => {
      const status = getStatus();
      return {
        running: status.running,
        logs: status.logs,
        qrCode: status.qrCode,
      };
    }),
    getDependencies: publicProcedure.query(async () => {
      const dependencies = await getDependencies();
      return {
        dependencies,
      };
    }),
    getLogs: publicProcedure.query(async () => {
      return getStatus().logs;
    }),
    getStatistics: publicProcedure.query(async () => {
      return getStatistics();
    }),
  }),
});

export type AppRouter = typeof appRouter;
