import { describe, it, expect, beforeAll, afterAll, vi } from 'vitest';
import * as fs from 'fs';
import * as path from 'path';
import { getFiles, getDependencies, getStatus } from './botManager';

const BOT_DIR = '/home/ubuntu/whatsapp-bot';

describe('botManager', () => {
  describe('getFiles', () => {
    it('deve retornar array de arquivos', async () => {
      const files = await getFiles();
      expect(Array.isArray(files)).toBe(true);
      expect(files.length).toBeGreaterThan(0);
    });

    it('deve incluir index.js, package.json e system_prompt.txt', async () => {
      const files = await getFiles();
      const fileNames = files.map(f => f.name);
      expect(fileNames).toContain('index.js');
      expect(fileNames).toContain('package.json');
      expect(fileNames).toContain('system_prompt.txt');
    });

    it('deve ter propriedades corretas em cada arquivo', async () => {
      const files = await getFiles();
      files.forEach(file => {
        expect(file).toHaveProperty('name');
        expect(file).toHaveProperty('content');
        expect(file).toHaveProperty('language');
        expect(typeof file.name).toBe('string');
        expect(typeof file.content).toBe('string');
        expect(['javascript', 'json', 'text']).toContain(file.language);
      });
    });

    it('index.js deve ter linguagem javascript', async () => {
      const files = await getFiles();
      const indexJs = files.find(f => f.name === 'index.js');
      expect(indexJs?.language).toBe('javascript');
    });

    it('package.json deve ter linguagem json', async () => {
      const files = await getFiles();
      const packageJson = files.find(f => f.name === 'package.json');
      expect(packageJson?.language).toBe('json');
    });

    it('system_prompt.txt deve ter linguagem text', async () => {
      const files = await getFiles();
      const systemPrompt = files.find(f => f.name === 'system_prompt.txt');
      expect(systemPrompt?.language).toBe('text');
    });
  });

  describe('getDependencies', () => {
    it('deve retornar objeto com dependências', async () => {
      const deps = await getDependencies();
      expect(typeof deps).toBe('object');
      expect(deps).not.toBeNull();
    });

    it('deve incluir groq-sdk, qrcode-terminal e whatsapp-web.js', async () => {
      const deps = await getDependencies();
      expect(deps).toHaveProperty('groq-sdk');
      expect(deps).toHaveProperty('qrcode-terminal');
      expect(deps).toHaveProperty('whatsapp-web.js');
    });

    it('deve ter versões como strings', async () => {
      const deps = await getDependencies();
      Object.values(deps).forEach(version => {
        expect(typeof version).toBe('string');
      });
    });
  });

  describe('getStatus', () => {
    it('deve retornar objeto com propriedades running e logs', () => {
      const status = getStatus();
      expect(status).toHaveProperty('running');
      expect(status).toHaveProperty('logs');
    });

    it('deve ter running como boolean', () => {
      const status = getStatus();
      expect(typeof status.running).toBe('boolean');
    });

    it('deve ter logs como array', () => {
      const status = getStatus();
      expect(Array.isArray(status.logs)).toBe(true);
    });

    it('bot deve estar parado inicialmente', () => {
      const status = getStatus();
      expect(status.running).toBe(false);
    });
  });
});
