import { spawn, ChildProcess } from 'child_process';
import * as fs from 'fs';
import * as path from 'path';

const BOT_DIR = '/home/ubuntu/whatsapp-bot';

interface BotProcess {
  process: ChildProcess | null;
  logs: string[];
  running: boolean;
  qrCode: string | null;
  startTime: number | null;
  messageCount: number;
  messageHistory: Array<{ timestamp: number; count: number }>;
}

let botState: BotProcess = {
  process: null,
  logs: [],
  running: false,
  qrCode: null,
  startTime: null,
  messageCount: 0,
  messageHistory: [],
};

export async function getFiles() {
  const files = [
    { name: 'index.js', path: path.join(BOT_DIR, 'index.js') },
    { name: 'package.json', path: path.join(BOT_DIR, 'package.json') },
    { name: 'system_prompt.txt', path: path.join(BOT_DIR, 'system_prompt.txt') },
  ];

  const result = [];
  for (const file of files) {
    try {
      const content = fs.readFileSync(file.path, 'utf-8');
      result.push({
        name: file.name,
        content,
        language: file.name.endsWith('.js') ? 'javascript' : file.name.endsWith('.json') ? 'json' : 'text',
      });
    } catch (error) {
      console.error(`Erro ao ler ${file.name}:`, error);
      result.push({
        name: file.name,
        content: '',
        language: file.name.endsWith('.js') ? 'javascript' : file.name.endsWith('.json') ? 'json' : 'text',
      });
    }
  }

  return result;
}

export async function saveFiles(files: Array<{ name: string; content: string }>) {
  for (const file of files) {
    const filePath = path.join(BOT_DIR, file.name);
    try {
      fs.writeFileSync(filePath, file.content, 'utf-8');
      addLog(`✅ ${file.name} salvo com sucesso`);
    } catch (error) {
      console.error(`Erro ao salvar ${file.name}:`, error);
      addLog(`❌ Erro ao salvar ${file.name}`);
      throw new Error(`Falha ao salvar ${file.name}`);
    }
  }
}

export async function getDependencies() {
  try {
    const packageJsonPath = path.join(BOT_DIR, 'package.json');
    const packageJson = JSON.parse(fs.readFileSync(packageJsonPath, 'utf-8'));
    return packageJson.dependencies || {};
  } catch (error) {
    console.error('Erro ao ler dependências:', error);
    return {};
  }
}

export async function startBot() {
  if (botState.running) {
    throw new Error('Bot já está rodando');
  }

  try {
    botState.logs = [];
    botState.qrCode = null;
    botState.startTime = Date.now();
    botState.messageCount = 0;
    botState.messageHistory = [];
    addLog('🚀 Iniciando bot de WhatsApp...');

    botState.process = spawn('node', ['index.js'], {
      cwd: BOT_DIR,
      stdio: ['pipe', 'pipe', 'pipe'],
      env: {
        ...process.env,
        CHROMIUM_PATH: '/usr/bin/chromium-browser',
      },
    });

    botState.process.stdout?.on('data', (data) => {
      const message = data.toString().trim();
      if (message) {
        // Detectar QR code em base64
        if (message.startsWith('QR_CODE_DATA:')) {
          const qrDataUrl = message.replace('QR_CODE_DATA:', '');
          botState.qrCode = qrDataUrl;
          addLog('📱 QR CODE GERADO - Escaneie com WhatsApp');
        } else if (message.includes('📩 Nova mensagem')) {
          // Contar mensagens recebidas
          botState.messageCount++;
          recordMessageHistory();
          addLog(`📤 ${message}`);
        } else {
          addLog(`📤 ${message}`);
        }
      }
    });

    botState.process.stderr?.on('data', (data) => {
      const message = data.toString().trim();
      if (message) {
        addLog(`⚠️ ${message}`);
      }
    });

    botState.process.on('error', (error) => {
      addLog(`❌ Erro: ${error.message}`);
      botState.running = false;
    });

    botState.process.on('exit', (code) => {
      addLog(`🛑 Bot encerrado com código ${code}`);
      botState.running = false;
      botState.process = null;
      botState.startTime = null;
    });

    botState.running = true;
    addLog('✅ Bot iniciado com sucesso!');

    return { success: true, message: 'Bot iniciado' };
  } catch (error) {
    addLog(`❌ Erro ao iniciar bot: ${error}`);
    botState.running = false;
    throw error;
  }
}

export async function stopBot() {
  if (!botState.running || !botState.process) {
    throw new Error('Bot não está rodando');
  }

  try {
    addLog('⏹️ Parando bot...');
    botState.process.kill('SIGTERM');
    
    // Aguardar um pouco para o processo encerrar gracefully
    await new Promise(resolve => setTimeout(resolve, 2000));

    if (botState.process && !botState.process.killed) {
      botState.process.kill('SIGKILL');
    }

    botState.running = false;
    botState.process = null;
    botState.qrCode = null;
    botState.startTime = null;
    addLog('✅ Bot parado com sucesso');

    return { success: true, message: 'Bot parado' };
  } catch (error) {
    addLog(`❌ Erro ao parar bot: ${error}`);
    throw error;
  }
}

export function getStatus() {
  return {
    running: botState.running,
    logs: botState.logs,
    qrCode: botState.qrCode,
  };
}

export function getStatistics() {
  const uptime = botState.running && botState.startTime 
    ? Math.floor((Date.now() - botState.startTime) / 1000)
    : 0;

  return {
    messageCount: botState.messageCount,
    uptime,
    messageHistory: botState.messageHistory,
    running: botState.running,
  };
}

export function getLogs() {
  return botState.logs;
}

function recordMessageHistory() {
  const now = Date.now();
  const lastEntry = botState.messageHistory[botState.messageHistory.length - 1];

  // Se a última entrada foi há menos de 1 minuto, incrementar
  if (lastEntry && now - lastEntry.timestamp < 60000) {
    lastEntry.count++;
  } else {
    // Caso contrário, criar nova entrada
    botState.messageHistory.push({ timestamp: now, count: 1 });
  }

  // Manter apenas os últimos 60 minutos de histórico
  const oneHourAgo = now - 3600000;
  botState.messageHistory = botState.messageHistory.filter(
    entry => entry.timestamp > oneHourAgo
  );
}

function addLog(message: string) {
  const timestamp = new Date().toLocaleTimeString('pt-BR');
  const logMessage = `[${timestamp}] ${message}`;
  botState.logs.push(logMessage);

  // Manter apenas os últimos 100 logs
  if (botState.logs.length > 100) {
    botState.logs = botState.logs.slice(-100);
  }

  console.log(logMessage);
}
