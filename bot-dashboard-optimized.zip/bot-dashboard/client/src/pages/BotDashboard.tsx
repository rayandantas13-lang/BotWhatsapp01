import { useState, useEffect, useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Card } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Play, Square, Save, RefreshCw, Terminal, BarChart3 } from 'lucide-react';
import { trpc } from '@/lib/trpc';
import { QRCodeDisplay } from '@/components/QRCodeDisplay';
import { StatisticsPanel } from '@/components/StatisticsPanel';
import { Sidebar } from '@/components/Sidebar';

interface FileContent {
  name: string;
  content: string;
  language: 'javascript' | 'json' | 'text';
}

interface BotStatus {
  running: boolean;
  logs: string[];
  qrCode: string | null;
}

interface Statistics {
  messageCount: number;
  uptime: number;
  messageHistory: Array<{ timestamp: number; count: number }>;
  running: boolean;
}

export default function BotDashboard() {
  const [files, setFiles] = useState<FileContent[]>([
    { name: 'index.js', content: '', language: 'javascript' },
    { name: 'package.json', content: '', language: 'json' },
    { name: 'system_prompt.txt', content: '', language: 'text' },
  ]);

  const [activeFile, setActiveFile] = useState('index.js');
  const [botStatus, setBotStatus] = useState<BotStatus>({
    running: false,
    logs: [],
    qrCode: null,
  });
  const [statistics, setStatistics] = useState<Statistics>({
    messageCount: 0,
    uptime: 0,
    messageHistory: [],
    running: false,
  });
  const [dependencies, setDependencies] = useState<Record<string, string>>({});
  const [activeTab, setActiveTab] = useState('editor');
  const logsEndRef = useRef<HTMLDivElement>(null);

  // Queries e Mutations tRPC
  const getFilesQuery = trpc.bot.getFiles.useQuery();
  const getDependenciesQuery = trpc.bot.getDependencies.useQuery();
  const getStatusQuery = trpc.bot.getStatus.useQuery(undefined, {
    refetchInterval: 2000,
  });
  const getStatisticsQuery = trpc.bot.getStatistics.useQuery(undefined, {
    refetchInterval: 2000,
  });
  const saveFilesMutation = trpc.bot.saveFiles.useMutation();
  const startBotMutation = trpc.bot.start.useMutation();
  const stopBotMutation = trpc.bot.stop.useMutation();

  // Carregar arquivos do servidor
  useEffect(() => {
    if (getFilesQuery.data?.files) {
      const loadedFiles = getFilesQuery.data.files.map((f: any) => ({
        name: f.name,
        content: f.content,
        language: (f.language || 'text') as 'javascript' | 'json' | 'text',
      }));
      setFiles(loadedFiles);
    }
  }, [getFilesQuery.data]);

  // Auto-scroll para os logs mais recentes
  useEffect(() => {
    logsEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [botStatus.logs]);

  // Carregar dependências
  useEffect(() => {
    if (getDependenciesQuery.data?.dependencies) {
      setDependencies(getDependenciesQuery.data.dependencies);
    }
  }, [getDependenciesQuery.data]);

  // Carregar status do bot
  useEffect(() => {
    if (getStatusQuery.data) {
      setBotStatus({
        running: getStatusQuery.data?.running || false,
        logs: getStatusQuery.data?.logs || [],
        qrCode: getStatusQuery.data?.qrCode || null,
      });
    }
  }, [getStatusQuery.data]);

  // Carregar estatísticas
  useEffect(() => {
    if (getStatisticsQuery.data) {
      setStatistics({
        messageCount: getStatisticsQuery.data.messageCount || 0,
        uptime: getStatisticsQuery.data.uptime || 0,
        messageHistory: getStatisticsQuery.data.messageHistory || [],
        running: getStatisticsQuery.data.running || false,
      });
    }
  }, [getStatisticsQuery.data]);

  const handleFileChange = (content: string) => {
    setFiles(files.map(f =>
      f.name === activeFile ? { ...f, content } : f
    ));
  };

  const handleSaveFiles = async () => {
    try {
      await saveFilesMutation.mutateAsync(files);
    } catch (error) {
      console.error('Erro ao salvar arquivos:', error);
    }
  };

  const handleStartBot = async () => {
    try {
      await startBotMutation.mutateAsync();
    } catch (error) {
      console.error('Erro ao iniciar bot:', error);
    }
  };

  const handleStopBot = async () => {
    try {
      await stopBotMutation.mutateAsync();
    } catch (error) {
      console.error('Erro ao parar bot:', error);
    }
  };

  const currentFile = files.find(f => f.name === activeFile);

  return (
    <div className="min-h-screen bg-background text-foreground flex">
      {/* Scan Lines Effect */}
      <div className="scan-lines" />

      {/* Sidebar */}
      <Sidebar activeTab={activeTab} onTabChange={setActiveTab} />

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-6 md:p-8">
        <div className="max-w-6xl mx-auto space-y-6">
          {/* Header */}
          <div className="hud-corner p-6 border-2 border-[#ffd700] bg-[#0a0a0a] relative">
            <div className="flex items-center justify-between">
              <div>
                <h1 className="text-3xl md:text-4xl font-bold neon-text">
                  WHATSAPP BOT
                </h1>
                <p className="text-sm neon-text-silver mt-2">
                  Gerenciador Premium
                </p>
              </div>
              <div className={`w-4 h-4 rounded-full ${botStatus.running ? 'bg-[#00ff41] pulse-glow' : 'bg-[#666]'}`} />
            </div>
          </div>

          {/* Status Bar */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <Card className="border-2 border-[#ffd700] bg-[#0a0a0a] p-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-xs text-[#c0c0c0] uppercase tracking-widest">Status</p>
                  <p className={`text-lg font-bold ${botStatus.running ? 'neon-text' : 'text-[#666]'}`}>
                    {botStatus.running ? '🟢 RODANDO' : '🔴 PARADO'}
                  </p>
                </div>
              </div>
            </Card>

            <Card className="border-2 border-[#c0c0c0] bg-[#0a0a0a] p-4">
              <p className="text-xs text-[#c0c0c0] uppercase tracking-widest">Dependências</p>
              <p className="text-lg font-bold neon-text">
                {Object.keys(dependencies).length}
              </p>
            </Card>

            <Card className="border-2 border-[#ffd700] bg-[#0a0a0a] p-4">
              <p className="text-xs text-[#c0c0c0] uppercase tracking-widest">Mensagens</p>
              <p className="text-lg font-bold neon-text">{statistics.messageCount}</p>
            </Card>
          </div>

          {/* Tabs Content */}
          {activeTab === 'editor' && (
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* File Editor */}
              <div className="lg:col-span-2 space-y-4">
                <Card className="border-2 border-[#ffd700] bg-[#0a0a0a] overflow-hidden">
                  <div className="border-b-2 border-[#ffd700] p-4 flex items-center justify-between">
                    <h2 className="text-lg font-bold neon-text">EDITOR</h2>
                    <Button
                      size="sm"
                      className="bg-[#ffd700] hover:bg-[#daa520] text-[#000000] font-bold"
                      onClick={handleSaveFiles}
                      disabled={saveFilesMutation.isPending}
                    >
                      <Save className="w-4 h-4 mr-2" />
                      {saveFilesMutation.isPending ? 'Salvando...' : 'Salvar'}
                    </Button>
                  </div>

                  <Tabs value={activeFile} onValueChange={setActiveFile} className="w-full">
                    <TabsList className="bg-[#1a1a2e] border-b-2 border-[#ffd700] rounded-none w-full justify-start">
                      {files.map(file => (
                        <TabsTrigger
                          key={file.name}
                          value={file.name}
                          className="border-b-2 border-transparent data-[state=active]:border-[#ffd700] data-[state=active]:text-[#ffd700] text-[#c0c0c0] rounded-none"
                        >
                          {file.name}
                        </TabsTrigger>
                      ))}
                    </TabsList>

                    {files.map(file => (
                      <TabsContent key={file.name} value={file.name} className="p-0">
                        <textarea
                          value={file.content}
                          onChange={e => handleFileChange(e.target.value)}
                          className="w-full h-96 p-4 bg-[#0a0a0a] text-[#ffd700] font-mono text-sm border-0 focus:outline-none focus:ring-2 focus:ring-[#ffd700] resize-none"
                          style={{
                            fontFamily: "'Space Mono', monospace",
                            caretColor: '#ffd700',
                          }}
                          placeholder="Carregando arquivo..."
                        />
                      </TabsContent>
                    ))}
                  </Tabs>
                </Card>
              </div>

              {/* Control Panel */}
              <div className="space-y-4">
                {/* Bot Controls */}
                <Card className="border-2 border-[#c0c0c0] bg-[#0a0a0a] p-4">
                  <h3 className="text-sm font-bold neon-text-silver mb-4 uppercase tracking-widest">
                    Controles
                  </h3>
                  <div className="space-y-3">
                    <Button
                      onClick={handleStartBot}
                      disabled={botStatus.running || startBotMutation.isPending}
                      className="w-full bg-[#ffd700] hover:bg-[#daa520] text-[#000000] font-bold border-2 border-[#ffd700]"
                    >
                      <Play className="w-4 h-4 mr-2" />
                      {startBotMutation.isPending ? 'INICIANDO...' : 'INICIAR'}
                    </Button>
                    <Button
                      onClick={handleStopBot}
                      disabled={!botStatus.running || stopBotMutation.isPending}
                      className="w-full bg-[#c0c0c0] hover:bg-[#a9a9a9] text-[#000000] font-bold border-2 border-[#c0c0c0]"
                    >
                      <Square className="w-4 h-4 mr-2" />
                      {stopBotMutation.isPending ? 'PARANDO...' : 'PARAR'}
                    </Button>
                  </div>
                </Card>

                {/* Dependencies */}
                <Card className="border-2 border-[#ffd700] bg-[#0a0a0a] p-4">
                  <h3 className="text-sm font-bold neon-text mb-4 uppercase tracking-widest">
                    Dependências
                  </h3>
                  <div className="space-y-2 max-h-48 overflow-y-auto">
                    {Object.entries(dependencies).length > 0 ? (
                      Object.entries(dependencies).map(([name, version]) => (
                        <div key={name} className="text-xs">
                          <p className="text-[#ffd700]">{name}</p>
                          <p className="text-[#666] text-xs">{version as string}</p>
                        </div>
                      ))
                    ) : (
                      <p className="text-[#666] text-xs">Carregando dependências...</p>
                    )}
                  </div>
                </Card>
              </div>
            </div>
          )}

          {/* Statistics Tab */}
          {activeTab === 'statistics' && (
            <StatisticsPanel 
              messageCount={statistics.messageCount}
              uptime={statistics.uptime}
              messageHistory={statistics.messageHistory}
            />
          )}

          {/* Logs Tab */}
          {activeTab === 'logs' && (
            <div className="space-y-4">
              {/* QR Code Display */}
              {botStatus.qrCode && botStatus.running && (
                <QRCodeDisplay qrData={botStatus.qrCode} isRunning={botStatus.running} />
              )}

              {/* Logs */}
              <Card className="border-2 border-[#c0c0c0] bg-[#0a0a0a] overflow-hidden">
                <div className="border-b-2 border-[#c0c0c0] p-4 flex items-center justify-between">
                  <h2 className="text-lg font-bold neon-text-silver flex items-center gap-2">
                    <Terminal className="w-5 h-5" />
                    LOGS
                  </h2>
                  <Button
                    size="sm"
                    variant="outline"
                    className="border-[#ffd700] text-[#ffd700] hover:bg-[#ffd700] hover:text-[#000000]"
                    onClick={() => getStatusQuery.refetch()}
                  >
                    <RefreshCw className="w-4 h-4" />
                  </Button>
                </div>

                <div className="p-4 min-h-48 bg-[#0a0a0a] font-mono text-xs">
                  <div className="max-h-96 overflow-y-auto">
                    {botStatus.logs.length > 0 ? (
                      botStatus.logs.map((log, idx) => (
                        <div key={idx} className="text-[#ffd700] mb-1 leading-relaxed break-words">
                          {log}
                        </div>
                      ))
                    ) : (
                      <p className="text-[#666]">Nenhum log disponível. Inicie o bot para ver os logs.</p>
                    )}
                    <div ref={logsEndRef} />
                  </div>
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
