import { LineChart, Line, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';
import { Card } from '@/components/ui/card';
import { Clock, MessageSquare, TrendingUp } from 'lucide-react';

interface StatisticsPanelProps {
  messageCount: number;
  uptime: number;
  messageHistory: Array<{ timestamp: number; count: number }>;
}

export function StatisticsPanel({ messageCount, uptime, messageHistory }: StatisticsPanelProps) {
  // Formatar uptime
  const formatUptime = (seconds: number) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    } else if (minutes > 0) {
      return `${minutes}m ${secs}s`;
    } else {
      return `${secs}s`;
    }
  };

  // Preparar dados para o gráfico
  const chartData = messageHistory.map(entry => ({
    time: new Date(entry.timestamp).toLocaleTimeString('pt-BR', { 
      hour: '2-digit', 
      minute: '2-digit' 
    }),
    messages: entry.count,
    timestamp: entry.timestamp,
  }));

  // Calcular média de mensagens por minuto
  const avgMessagesPerMinute = messageHistory.length > 0 
    ? (messageCount / messageHistory.length).toFixed(2)
    : '0.00';

  return (
    <div className="space-y-4">
      {/* Cards de Resumo */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <Card className="border-2 border-[#ff006e] bg-[#0a0a0a] p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-[#b537f2] uppercase tracking-widest">Mensagens</p>
              <p className="text-2xl font-bold neon-text">{messageCount}</p>
              <p className="text-xs text-[#666] mt-1">Total processadas</p>
            </div>
            <MessageSquare className="w-8 h-8 text-[#ff006e]" />
          </div>
        </Card>

        <Card className="border-2 border-[#00f0ff] bg-[#0a0a0a] p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-[#00f0ff] uppercase tracking-widest">Uptime</p>
              <p className="text-2xl font-bold neon-text-cyan">{formatUptime(uptime)}</p>
              <p className="text-xs text-[#666] mt-1">Tempo de atividade</p>
            </div>
            <Clock className="w-8 h-8 text-[#00f0ff]" />
          </div>
        </Card>

        <Card className="border-2 border-[#b537f2] bg-[#0a0a0a] p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-xs text-[#b537f2] uppercase tracking-widest">Média</p>
              <p className="text-2xl font-bold neon-text">{avgMessagesPerMinute}</p>
              <p className="text-xs text-[#666] mt-1">Msg/minuto</p>
            </div>
            <TrendingUp className="w-8 h-8 text-[#b537f2]" />
          </div>
        </Card>
      </div>

      {/* Gráfico de Histórico */}
      {chartData.length > 0 && (
        <Card className="border-2 border-[#00f0ff] bg-[#0a0a0a] p-4">
          <h3 className="text-sm font-bold neon-text-cyan mb-4 uppercase tracking-widest">
            📊 Histórico de Mensagens
          </h3>
          <ResponsiveContainer width="100%" height={300}>
            <LineChart data={chartData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#333" />
              <XAxis 
                dataKey="time" 
                stroke="#666"
                style={{ fontSize: '12px' }}
              />
              <YAxis 
                stroke="#666"
                style={{ fontSize: '12px' }}
              />
              <Tooltip 
                contentStyle={{
                  backgroundColor: '#1a1a2e',
                  border: '2px solid #ff006e',
                  borderRadius: '4px',
                }}
                labelStyle={{ color: '#00f0ff' }}
              />
              <Legend 
                wrapperStyle={{ color: '#00f0ff' }}
              />
              <Line 
                type="monotone" 
                dataKey="messages" 
                stroke="#ff006e" 
                strokeWidth={2}
                dot={{ fill: '#ff006e', r: 4 }}
                activeDot={{ r: 6 }}
                name="Mensagens"
              />
            </LineChart>
          </ResponsiveContainer>
        </Card>
      )}

      {/* Mensagem quando não há dados */}
      {chartData.length === 0 && (
        <Card className="border-2 border-[#666] bg-[#0a0a0a] p-4">
          <p className="text-[#666] text-center text-sm">
            Inicie o bot para ver o histórico de mensagens
          </p>
        </Card>
      )}
    </div>
  );
}
