import { useRef } from 'react';
import { Button } from '@/components/ui/button';
import { Download } from 'lucide-react';

interface QRCodeDisplayProps {
  qrData: string | null;
  isRunning: boolean;
}

export function QRCodeDisplay({ qrData, isRunning }: QRCodeDisplayProps) {
  const handleDownload = () => {
    if (qrData && qrData.startsWith('data:image')) {
      const link = document.createElement('a');
      link.href = qrData;
      link.download = 'qrcode.png';
      link.click();
    }
  };

  if (!isRunning || !qrData) {
    return null;
  }

  const isDataUrl = qrData.startsWith('data:image');

  return (
    <div className="flex flex-col items-center justify-center gap-4 p-6 border-2 border-[#ff006e] bg-[#1a1a2e] rounded">
      <div className="text-center">
        <p className="text-[#ff006e] font-bold mb-2 neon-text">📱 ESCANEIE COM WHATSAPP</p>
        <p className="text-[#00f0ff] text-sm mb-4">Abra WhatsApp no seu celular e aponte a câmera</p>
      </div>

      <div
        className="p-4 bg-white rounded"
        style={{
          boxShadow: '0 0 20px rgba(255, 0, 110, 0.5), 0 0 40px rgba(0, 240, 255, 0.3)',
        }}
      >
        {isDataUrl ? (
          <img src={qrData} alt="QR Code" className="w-64 h-64" />
        ) : (
          <div className="w-64 h-64 flex items-center justify-center text-[#666]">
            Gerando QR Code...
          </div>
        )}
      </div>

      <Button
        size="sm"
        onClick={handleDownload}
        className="border-[#00f0ff] text-[#00f0ff] hover:bg-[#00f0ff] hover:text-[#0a0a0a]"
      >
        <Download className="w-4 h-4 mr-2" />
        Baixar QR Code
      </Button>
    </div>
  );
}
