import { BarChart3, FileText, Terminal, LogOut, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';

interface SidebarProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
  onLogout?: () => void;
}

export function Sidebar({ activeTab, onTabChange, onLogout }: SidebarProps) {
  const menuItems = [
    { id: 'editor', label: 'Dashboard', icon: FileText },
    { id: 'statistics', label: 'Estatísticas', icon: BarChart3 },
    { id: 'logs', label: 'Logs', icon: Terminal },
  ];

  return (
    <div className="w-64 bg-[#0a0a0a] border-r-2 border-[#ffd700] flex flex-col h-screen">
      {/* Logo/Header */}
      <div className="p-6 border-b-2 border-[#ffd700]">
        <h1 className="text-xl font-bold neon-text">BOT MANAGER</h1>
        <p className="text-xs neon-text-silver mt-2">Gerenciador Premium</p>
      </div>

      {/* Menu Items */}
      <nav className="flex-1 p-4 space-y-2">
        {menuItems.map(item => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className={`w-full flex items-center gap-3 px-4 py-3 rounded transition-all ${
                isActive
                  ? 'bg-[#ffd700] text-[#000000] font-bold'
                  : 'text-[#c0c0c0] hover:text-[#ffd700] hover:bg-[#1a1a2e]'
              }`}
            >
              <Icon className="w-5 h-5" />
              <span>{item.label}</span>
            </button>
          );
        })}
      </nav>

      {/* Footer */}
      <div className="p-4 border-t-2 border-[#ffd700] space-y-2">
        <Button
          variant="outline"
          className="w-full border-[#ffd700] text-[#c0c0c0] hover:bg-[#ffd700] hover:text-[#000000]"
        >
          <Settings className="w-4 h-4 mr-2" />
          Configurações
        </Button>
        <Button
          variant="outline"
          onClick={onLogout}
          className="w-full border-[#ffd700] text-[#c0c0c0] hover:bg-[#ffd700] hover:text-[#000000]"
        >
          <LogOut className="w-4 h-4 mr-2" />
          Sair
        </Button>
      </div>
    </div>
  );
}
