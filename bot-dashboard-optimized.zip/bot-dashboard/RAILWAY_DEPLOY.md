# Deploy na Railway

## Pré-requisitos

1. Conta no [Railway](https://railway.app)
2. Conta no [GitHub](https://github.com)
3. Git instalado localmente

## Passo 1: Fazer Push para GitHub

```bash
# Inicializar repositório Git (se não existir)
git init
git add .
git commit -m "Initial commit: WhatsApp Bot Dashboard"

# Criar repositório no GitHub e fazer push
git remote add origin https://github.com/seu-usuario/bot-dashboard.git
git branch -M main
git push -u origin main
```

## Passo 2: Conectar Railway ao GitHub

1. Acesse [railway.app](https://railway.app)
2. Clique em "New Project"
3. Selecione "Deploy from GitHub"
4. Autorize o Railway a acessar sua conta GitHub
5. Selecione o repositório `bot-dashboard`

## Passo 3: Configurar Variáveis de Ambiente

No dashboard do Railway, adicione as seguintes variáveis de ambiente:

```
DATABASE_URL=mysql://user:password@host:3306/database
JWT_SECRET=sua-chave-secreta-aqui
VITE_APP_ID=seu-app-id
OAUTH_SERVER_URL=https://api.manus.im
VITE_OAUTH_PORTAL_URL=https://portal.manus.im
OWNER_OPEN_ID=seu-open-id
OWNER_NAME=seu-nome
BUILT_IN_FORGE_API_URL=https://api.manus.im
BUILT_IN_FORGE_API_KEY=sua-chave-api
VITE_FRONTEND_FORGE_API_KEY=sua-chave-frontend
VITE_FRONTEND_FORGE_API_URL=https://api.manus.im
```

## Passo 4: Deploy Automático

1. O Railway detectará automaticamente que é um projeto Node.js
2. Executará `pnpm install` e `pnpm build`
3. Iniciará o servidor com `pnpm start`

## Passo 5: Acessar a Aplicação

Após o deploy bem-sucedido, você receberá uma URL pública como:
```
https://bot-dashboard-production.up.railway.app
```

## Troubleshooting

### Erro: "pnpm not found"
Railway usa npm por padrão. Adicione um arquivo `railway.json`:

```json
{
  "builder": "nixpacks",
  "buildCommand": "pnpm install && pnpm build",
  "startCommand": "pnpm start"
}
```

### Erro: "DATABASE_URL not set"
Certifique-se de que adicionou todas as variáveis de ambiente necessárias no dashboard do Railway.

### Erro: "Port already in use"
O servidor está configurado para usar a porta definida em `process.env.PORT` (padrão: 3000).

## Atualizações Futuras

Após fazer push para GitHub, o Railway fará deploy automático a cada novo commit na branch `main`.

```bash
git add .
git commit -m "Feature: Nova funcionalidade"
git push origin main
# Railway fará deploy automaticamente
```

## Rollback

Para reverter para uma versão anterior:

1. Acesse o dashboard do Railway
2. Vá para "Deployments"
3. Selecione a versão anterior
4. Clique em "Redeploy"
