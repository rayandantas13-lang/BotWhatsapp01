# Bot Dashboard TODO

## Funcionalidades Principais

- [x] Configurar design system cyberpunk (cores, tipografia, efeitos neon)
- [x] Gerenciador de arquivos com listagem de arquivos do bot
- [x] Editor de código com syntax highlighting para index.js
- [x] Editor de código com syntax highlighting para package.json
- [x] Editor de código com syntax highlighting para system_prompt.txt
- [x] Botão para salvar alterações nos arquivos
- [x] Visualizador de logs em tempo real do bot
- [x] Controle para iniciar o bot
- [x] Controle para parar o bot
- [x] Indicador de status do bot (rodando/parado)
- [x] Painel de informações com dependências instaladas
- [x] Integração com backend para gerenciar arquivos
- [x] Integração com backend para executar bot
- [x] Integração com backend para capturar logs em tempo real
- [x] Testes das funcionalidades principais

## Correções Solicitadas

- [x] Carregar arquivos reais do bot no editor
- [x] Instalar dependências do bot (npm install)
- [x] Adicionar suporte para exibir QR code no painel de logs
- [x] Melhorar captura de saída do bot para exibir QR code

## Melhorias Solicitadas

- [x] Renderizar QR code visual (SVG) para escanear com WhatsApp
- [x] Capturar dados do QR code do bot e exibir no dashboard

## Painel de Estatísticas

- [x] Criar modelo de dados para rastrear mensagens processadas
- [x] Implementar contador de mensagens no botManager
- [x] Criar componente de gráfico de histórico de mensagens
- [x] Criar componente de tempo de atividade do bot
- [x] Integrar gráficos no dashboard
- [x] Adicionar rota tRPC para obter estatísticas


## Redesign Gold & Silver

- [x] Atualizar paleta de cores para ouro, prata e preto
- [x] Implementar sidebar de navegação
- [x] Redesenhar componentes com novo esquema de cores
- [x] Atualizar index.css com novas variáveis de tema
- [x] Testar e validar novo design
