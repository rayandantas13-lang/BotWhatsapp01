# Setup no GitHub

## Passo 1: Preparar o Repositório Local

```bash
# Navegar para o diretório do projeto
cd bot-dashboard

# Inicializar Git (se não estiver inicializado)
git init

# Adicionar todos os arquivos
git add .

# Fazer commit inicial
git commit -m "Initial commit: WhatsApp Bot Dashboard with Gold & Silver theme"
```

## Passo 2: Criar Repositório no GitHub

1. Acesse [github.com/new](https://github.com/new)
2. Nome do repositório: `bot-dashboard`
3. Descrição: "WhatsApp Bot Manager Dashboard com editor de código e estatísticas"
4. Escolha entre público ou privado
5. **NÃO** inicialize com README, .gitignore ou license (já temos)
6. Clique em "Create repository"

## Passo 3: Fazer Push para GitHub

```bash
# Adicionar remote do GitHub
git remote add origin https://github.com/seu-usuario/bot-dashboard.git

# Renomear branch para main (se necessário)
git branch -M main

# Fazer push
git push -u origin main
```

## Passo 4: Configurar Proteção de Branch (Opcional)

1. Acesse o repositório no GitHub
2. Vá para Settings → Branches
3. Clique em "Add rule"
4. Nome do padrão: `main`
5. Ative "Require pull request reviews before merging"
6. Clique em "Create"

## Passo 5: Adicionar Secrets (Opcional)

Para usar GitHub Actions com deploy automático:

1. Vá para Settings → Secrets and variables → Actions
2. Clique em "New repository secret"
3. Adicione as variáveis sensíveis:
   - `DATABASE_URL`
   - `JWT_SECRET`
   - `OAUTH_SERVER_URL`
   - etc.

## Atualizações Futuras

```bash
# Fazer alterações
git add .
git commit -m "Descrição das mudanças"
git push origin main
```

## Estrutura do Repositório

```
bot-dashboard/
├── client/                 # Frontend React
│   ├── src/
│   │   ├── pages/         # Páginas principais
│   │   ├── components/    # Componentes reutilizáveis
│   │   ├── lib/           # Utilitários
│   │   └── index.css      # Estilos globais
│   └── public/            # Arquivos estáticos
├── server/                # Backend Express + tRPC
│   ├── routers.ts         # Rotas tRPC
│   ├── db.ts              # Queries do banco
│   └── botManager.ts      # Lógica do bot
├── drizzle/               # Migrations do banco
├── dist/                  # Build compilado
├── node_modules/          # Dependências (não commitado)
├── package.json           # Dependências do projeto
├── pnpm-lock.yaml         # Lock file
├── RAILWAY_DEPLOY.md      # Instruções de deploy
└── README.md              # Documentação
```

## Branches Recomendadas

- `main`: Código em produção
- `develop`: Código em desenvolvimento
- `feature/nome-da-feature`: Novas funcionalidades
- `bugfix/nome-do-bug`: Correções de bugs

## Commits Semânticos

Use prefixos nos commits para melhor organização:

```bash
git commit -m "feat: Adicionar nova funcionalidade"
git commit -m "fix: Corrigir bug no editor"
git commit -m "docs: Atualizar documentação"
git commit -m "style: Ajustar estilos CSS"
git commit -m "refactor: Reorganizar código"
git commit -m "test: Adicionar testes"
git commit -m "chore: Atualizar dependências"
```

## Ignorar Arquivos Sensíveis

O arquivo `.gitignore` já está configurado para ignorar:
- `.env` e variáveis de ambiente
- `node_modules`
- Arquivos de build
- Logs
- Arquivos de autenticação do WhatsApp

## Clonar o Repositório em Outro Local

```bash
git clone https://github.com/seu-usuario/bot-dashboard.git
cd bot-dashboard
pnpm install
pnpm dev
```
